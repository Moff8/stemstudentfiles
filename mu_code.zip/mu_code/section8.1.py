# Write your code here :-)
import pgzrun
import random

WIDTH =500
HEIGHT = 500

background = Actor("background500500")
player = Actor("robot")
player.x=200
player.y=200

enemy = Actor("alien", anchor=(0,0), pos = (50,50))
enemies = [enemy]


coin = Actor("items/coinsilver")
score = 0
time = 20


def draw():
    screen.clear()
    background.draw()
    player.draw()
    for enemy in enemies:
        enemy.draw()
    coin.draw()
    screen.draw.text("My game", (200,0), color="red")
    score_string = str(score)
    screen.draw.text((f"Score: {score_string}"), (0,0), color="green")
    time_string = str(time)
    screen.draw.text(time_string, (400,0), color="green")

def update(delta):
    global score, time
    time=time-delta
    if time <= 0:
        exit()
    # Handle the movement of the robot.
    if keyboard.right:
        player.x +=4
    if keyboard.left:
        player.x -=4
    if keyboard.up:
        player.y -=4
    if keyboard.down:
        player.y +=4
    # Deal with exceeding the edges of the window by wrapping
    if player.x > WIDTH:
        player.x = 0
    if player.x <0:
        player.x = WIDTH
    if player.y <0:
        player.y = HEIGHT
    if player.y > HEIGHT:
        player.y = 0

    # follow player position
    if enemy.x < player.x:
        enemy.x +=random.randint(0,1)
    if enemy.x > player.x:
        enemy.x -=1
    if enemy.y < player.y:
        enemy.y +=1
    if enemy.y > player.y:
        enemy.y -=1
    if coin.colliderect(player):
        coin.x = random.randint(0, WIDTH)
        coin.y = random.randint(0,HEIGHT)
        score += 1
        print(f"Score: {score}")
    if keyboard.space:
        enemies.append(enemy)

    if enemy.colliderect(player):
        exit()





pgzrun.go()
