import pgzrun

WIDTH = 457
HEIGHT=457

alien = Actor('alien')
alien.pos = (0,50)

background = Actor('background500500')


def draw():
    screen.clear()
    background.draw()
    alien.draw()

def update():
    if keyboard.d:
        alien.x+=2
    elif keyboard.a:
        alien.x-=2
    elif keyboard.w:
        alien.y-=2
    elif keyboard.s:
        alien.y+=2

pgzrun.go()
