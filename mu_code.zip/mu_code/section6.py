# Write your code here :-)

'''
import pygame
Width = 500
HEIGHT = 500

joystick = pygame.joystick.Joystick(0)
joystick.init()

alien= Actor("Alien")
alien.pos =(0, 50)

def draw():
    screen.clear()
    alien.draw()

def update():
    if keyboard.right or joystick.get_axis(0) > 0.1:
        alien.x += 2
    elif keyboard.left or joystick.get_axis(0) < -0.1:
        alien.x -+ 2
'''
'''
import pgzrun
import random
#my_colour = (0,0,0) #makes black
#my_colour = (255,255,255) #makes white

red_amount = random.randint(0, 255)
green_amount = random.randint(0, 255)
blue_amount = random.randint(0, 255)

def draw():
    my_colour = (red_amount, blue_amount, green_amount)
    screen.fill(my_colour)

def update():
    global red_amount, green_amount, blue_amount
    red_amount+=2
    red_amount = red_amount % 255
    green_amount+=1
    green_amount = blue_amount % 255
    blue_amount+=3
    blue_amount = blue_amount % 255



import pgzrun
import random

WIDTH = 500
HEIGHT = 500

def draw():
    screen.clear()
    for x in range(0, WIDTH, 40):
        screen.draw.filled_circle((x, 20), 20, "red")

    for x in range(0,WIDTH,40):
        #for y in range(60,HEIGHT,40):
        y = random.randint(60, 400)
        screen.draw.filled_circle((x, y), 10, "green")
    screen.draw.filled_circle((random.randint(0, 400),random.randint(0, 400)), 20, "blue")

import pgzrun
import pygame

WIDTH = 500
HEIGHT = 500

alien = Actor("alien")

def draw():
    screen.clear()
    alien.draw()

def update():
    if keyboard.f:
        pygame.display.set_mode((WIDTH, HEIGHT), pygame.FULLSCREEN)
    if keyboard.escape:
        exit()
'''

import pgzrun

WIDTH = 500
HEIGHT = 500

score1 = 0
score2 = 0

def draw():
    screen.clear()
    screen.draw.text(f"Player 1 score: {score1}", (0,0), fontsize = 30, background = "blue")
    screen.draw.text(f"Player 2 score: {score2}", (0,470), fontsize = 30, background = "red")
    screen.draw.textbox("Hello mum", Rect(50,50,200,200))

def on_key_down(key):
    global score1, score2
    if key==keys.SPACE:
        score1+=1
    elif key==key.LEFT:
        score2+=1


pgzrun.go()
