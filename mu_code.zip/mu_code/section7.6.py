# Write your code here :-)
import pgzrun
import random

aliens = []


def add_alien():
    if len(aliens) < 10:
        aliens.append(Actor("alien", (random.randint(0, 500), random.randint(0, 500))))


# call add_alien once, 0.5 seconds from now
clock.schedule_unique(add_alien, 0.5)

# call add_alien over and over again every 2 seconds
clock.schedule_interval(add_alien, 1.0)


def draw():
    screen.clear()
    for alien in aliens:
        alien.draw()


pgzrun.go()
