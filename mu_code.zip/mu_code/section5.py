# Write your code here :-)
import pgzrun


import random
import time

WIDTH = 500
HEIGHT = 500

alien = Actor("alien")
alien.pos =(400, 40)
box = Rect((20,20),(10,10))
robot = Actor("robot")
robot.pos = (20,20)
score=0

def draw():
    screen.clear()
    screen.draw.filled_rect(box, "red")
    screen.draw.text(f"Player 1 score: {score}", (0,0), fontsize = 30, background = "blue")
    robot.draw()
    alien.draw()
def drawlose():
    screen.clear()
    screen.draw.textbox("Hello mum", Rect(50,50,200,200))

def update():
    if keyboard.right:
        alien.x = alien.x + 3
    elif keyboard.left:
        alien.x = alien.x - 3
    if keyboard.up:
        alien.y = alien.y - 3
    elif keyboard.down:
        alien.y = alien.y + 3
    alien.image="alien"

    if robot.x > alien.x:
        robot.x = robot.x - 1
    elif robot.x < alien.x:
       robot.x = robot.x + 1
    if robot.y > alien.y:
        robot.y = robot.y - 1
    elif robot.y < alien.y:
       robot.y = robot.y + 1

    if box.x > WIDTH:
        box.x = 0
    if alien.colliderect(box):
        global score
        alien.image ="alien"
        box.x = random.randint(0, WIDTH)
        box.y = random.randint(0, HEIGHT)
        score = score + 1
        print("Score", score)
    elif alien.colliderect(robot):
        alien.image ="alien_hurt"
        sounds.eep.play()
        robot.x = random.randint(0, WIDTH)
        robot.y = random.randint(0, HEIGHT)
        score -= 1
        print("Score", score)
    elif score <0:
        drawlose()
        time.sleep(5)
        exit()

'''
def on_mouse_down(pos,button):
    global score
    if button == mouse.LEFT and alien.colliderect(pos):
        alien.image = 'alien_hurt'
        sounds.eep.play()
        score= score + 1


alien = Actor("alien")

def draw():
    screen.clear()
    alien.draw()

def on_mouse_move(pos):
    alien.pos = pos

alien = Actor("alien")
alien.pos = (0, 50)
score = 0

def draw():
    screen.clear()
    alien.draw()
    screen.draw.text("Score "+str(score), (0,0))

def update():
    if keyboard.right:
        alien.x = alien.x + 2
    elif keyboard.left:
        alien.x = alien.x - 2
    alien.image = 'alien'

def on_mouse_down(pos, button):
    global score
    if button == mouse.LEFT and alien.collidepoint(pos):
        alien.image = 'alien_hurt'
        sounds.eep.play()
        score = score + 1


# wiggle your mouse around the screen!

alien = Actor("alien")

def draw():
    screen.clear()
    alien.draw()


def on_mouse_down(pos, button):
    #alien.pos = pos
    animate(alien, pos=pos, duration=1, tween='bounce_end')
'''

pgzrun.go()
