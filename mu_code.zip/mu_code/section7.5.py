# Write your code here :-)
import pgzrun

timer = 0

def update(dt):
    global timer
    timer+=dt

def draw():
    screen.clear()
    screen.draw.text(f"Time passed: {timer}", (0,0))
    if timer > 3:
        screen.draw.textbox("Times up! Press SPACE to exit", Rect(100,100,200,200))
    if keyboard.space:
        exit()



pgzrun.go()
