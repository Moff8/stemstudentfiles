import pgzrun
'''
WIDTH = 500
HEIGHT = 500

aliens = []

for i in range(0,10):
    aliens.append(Actor('alien', (i*30, i*30)))

def draw():
    screen.clear()
    for alien in aliens:
        alien.draw()

def update():
    for alien in aliens:
        alien.x+=2
        if alien.x > WIDTH:
            alien.x =30

def on_mouse_down(pos, button):
    aliens.append(Actor('alien', pos))



WIDTH = 500
HEIGHT = 500

alien = Actor("alien")
alien.pos = (400, 50)
box = Rect((20, 20), (20, 20))


bullets=[]

def draw():
    screen.clear()
    screen.draw.filled_rect(box, "red")
    alien.draw()
    for bullet in bullets:
        #bullet.draw()
        screen.draw.filled_rect(bullet, "green")

def on_key_down(key):
    if key == keys.SPACE:
        print("space")
        #bullet=Actor('bulletgreen2', pos=(alien.x, alien.y))
        bullet = Rect((alien.x, alien.y), (20,20))
        bullets.append(bullet)

def move_bullets():
    for bullet in bullets:
        bullet.y+= 6
        if bullet.y > HEIGHT:
            bullets.remove(bullet)

def update():
    if keyboard.right:
        alien.x = alien.x + 2
    elif keyboard.left:
        alien.x = alien.x - 2
    box.x = box.x + 2
    if box.x > WIDTH:
        box.x = 0
    if alien.colliderect(box):
        print("hit")
    move_bullets()
'''

WIDTH = 500
HEIGHT = 500

ball = Rect((200, 400), (20,20))

velx = 1
vely = 1

def draw():
    screen.clear()
    screen.draw.filled_rect(ball, "red")

def update():
    global velx, vely
    ball.x += velx
    ball.y += vely
    if ball.right >WIDTH or ball.left <0:
        velx *= -1.5
    if ball.bottom > HEIGHT or ball.top < 0:
        vely *= -1.5



pgzrun.go()
