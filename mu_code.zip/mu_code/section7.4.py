# Write your code here :-)
import pgzrun

import random

WIDTH = 500
HEIGHT = 500

timer = 0
ball = Rect((10, 40), (20,20))
bat = Rect((200, 400), (60, 20))

velx = 3
vely = 3

def draw():
    global timer
    screen.clear()
    screen.draw.filled_rect(ball, "red")
    screen.draw.filled_rect(bat, "white")
    screen.draw.text(f"Time passed: {timer}", (0,0))

def update(dt):
    global velx, vely, timer
    timer+=dt
    ball.x += velx
    ball.y += vely
    if ball.right > WIDTH or ball.left < 0:
        velx = -velx
    if ball.top <0:
        vely = -vely
    if ball.colliderect(bat):
        velx = -1.1*(velx+random.randint(0,1))
        vely = -1.1*(vely+random.randint(0,1))
    if ball.bottom > HEIGHT:
        exit()
    if keyboard.right:
        bat.x+=4
    elif keyboard.left:
        bat.x-=4



pgzrun.go()
