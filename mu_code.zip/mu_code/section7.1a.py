# Write your code here :-)
import pgzrun

WIDTH = 500
HEIGHT = 500

alien = Actor("alien")
alien.pos = (400, 400)
box = Rect((20, 20), (15, 15))
bullet = Rect((alien.x, alien.y), (20,20))
bullets=[]
score=0


def draw():
    screen.clear()
    screen.draw.filled_rect(box, "red")
    alien.draw()
    for bullet in bullets:
        bullet.draw()

def update():
    if keyboard.right:
        alien.x = alien.x + 2
    elif keyboard.left:
        alien.x = alien.x - 2
    box.x = box.x + 2
    if box.x > WIDTH:
        box.x = 0
    if alien.colliderect(box):
        print("hit")
    if keyboard.space:
        bullets.append(Actor('bulletgreen2', alien.pos))
    for bullet in bullets:
        bullet.y = bullet.y - 5
        if bullet.colliderect(box):
            global score
            score+=1
            print(f"Score: {score}")
            bullets.remove(bullet)
        elif bullet.y <=0:
            bullets.remove(bullet)



pgzrun.go()
