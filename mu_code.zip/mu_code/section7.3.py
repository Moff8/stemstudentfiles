import pgzrun

WIDTH = 500
HEIGHT = 500

ball = Rect((200, 400), (20,20))

velx = 1
vely = 1

def draw():
    screen.clear()
    screen.draw.filled_rect(ball, "red")

def update():
    global velx, vely
    ball.x += velx
    ball.y += vely
    if ball.right >WIDTH or ball.left <0:
        velx *= -1.5
    if ball.bottom > HEIGHT or ball.top < 0:
        vely *= -1.5# Write your code here :-)

pgzrun.go()
